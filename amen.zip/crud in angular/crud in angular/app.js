// app.js
angular.module('shoppingApp', [])
  .controller('ShoppingController', function ($scope) {
    $scope.shoppingList = ['Apples', 'Bananas', 'Milk', 'Bread'];

    $scope.addItem = function () {
      if ($scope.newItem) {
        $scope.shoppingList.push($scope.newItem);
        $scope.newItem = '';
      }
    };

    $scope.deleteItem = function (index) {
      $scope.shoppingList.splice(index, 1);
    };
  });
