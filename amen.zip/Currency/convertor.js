// convertor.js

const convertor = {
    // Function to convert Celsius to Fahrenheit
    celsiusToFahrenheit: function(celsius) {
      return (celsius * 9/5) + 32;
    },
  
    // Function to convert Fahrenheit to Celsius
    fahrenheitToCelsius: function(fahrenheit) {
      return (fahrenheit - 32) * 5/9;
    },
  
    // Function to convert USD to EUR
    usdToEur: function(usdAmount) {
      // Assuming a simple conversion rate for demonstration purposes
      const conversionRate = 0.85;
      return usdAmount * conversionRate;
    },
  
    // Function to convert EUR to USD
    eurToUsd: function(eurAmount) {
      // Assuming a simple conversion rate for demonstration purposes
      const conversionRate = 1.18;
      return eurAmount * conversionRate;
    }
  };
  
  module.exports = convertor;
  