const no1 = parseFloat(prompt("Enter the value"));
document.write(no1);
document.write("<br>");