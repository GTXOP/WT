const fs = require('fs');

// File path
const filePath = 'example.txt';

// a) Create a file
fs.open(filePath, 'w', (err, file) => {
  if (err) throw err;
  console.log('File created successfully.');

  // b) Write to the file
  const contentToWrite = 'Hello, File Handling!';
  fs.writeFile(filePath, contentToWrite, (writeErr) => {
    if (writeErr) throw writeErr;
    console.log('Data written to the file successfully.');

    // c) Read from the file
    fs.readFile(filePath, 'utf8', (readErr, data) => {
      if (readErr) throw readErr;
      console.log('Data read from the file:');
      console.log(data);

      // d) Delete the file
      fs.unlink(filePath, (deleteErr) => {
        if (deleteErr) throw deleteErr;
        console.log('File deleted successfully.');
      });
    });
  });
});

