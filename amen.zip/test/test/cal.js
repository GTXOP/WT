function add()
{
 const Result = no1+no2
 // document.write(Result)
 window.alert(Result)
 // console.log(Result)
}

function sub()
{
 const Result = no1-no2
 // document.write(Result)
  window.alert(Result)
 //console.log(Result)
}

function multi()
{
 const Result = no1*no2
 // document.write(Result)
 window.alert(Result)
 //console.log(Result)
}

function div()
{
 const Result = no1/no2
 // document.write(Result)
 window.alert(Result)
 //console.log(Result)
}