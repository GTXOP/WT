// app.js
angular.module('myApp', [])
  .controller('myCtrl', function ($scope) {
    $scope.user = {};

    $scope.submitForm = function () {
      // Handle form submission logic here
      console.log('Form submitted:', $scope.user);
    };

    $scope.isValidUsername = function () {
      // Check if the username contains only alphabets
      return /^[a-zA-Z]+$/.test($scope.user.username);
    };

    $scope.isNumeric = function (value) {
      return !isNaN(parseFloat(value)) && isFinite(value);
    };
  });
