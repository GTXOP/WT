// app.js

const convertor = require('./convertor');

// Example temperature conversion
const celsiusTemperature = 25;
const fahrenheitTemperature = convertor.celsiusToFahrenheit(celsiusTemperature);

console.log(`${celsiusTemperature} Celsius is ${fahrenheitTemperature} Fahrenheit`);

// Example currency conversion
const usdAmount = 100;
const eurAmount = convertor.usdToEur(usdAmount);

console.log(`${usdAmount} USD is approximately ${eurAmount.toFixed(2)} EUR`);
