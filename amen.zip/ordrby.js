var mysql=require('mysql');
var con = mysql.createConnection({
 host:'localhost',
 user:'root',
 password:'',
 database:'medical_store'
})

con.connect(function(err){
 if(err){throw err;}
 console.log('connected!');

  //create table
// sql1='CREATE TABLE  cust_info(id int(50),Mname varchar(30),mfg date)';
 //con.query(sql1,function(err,result){
 //if(err){throw err;}
 //console.log('Table is created');
//});

 //order by
 sql1='select * from cust_info order by id desc;';
 con.query(sql1,function(err,result){
  if(err){throw err;}
  console.log(result);

  //where clause

  //sql1='select * from cust_info where id >= 5;';
 //con.query(sql1,function(err,result){
    //if(err){throw err;}
   // console.log(result);
    //})


        //drop table

 // var sql2 = 'DROP TABLE empinfo';
 // con.query(sql1, function (err, result) {
    // if (err) throw err;
    // console.log('Table empinfo deleted successfully...');
 //});

    //insert 

 //sql1='INSERT INTO cust_info(id ,fname,lname,Mob_No,med_name) VALUES ?;';
 //let val = [[1,"ramesh","warang",7894561235,"petoxin"],
 // [2,"sai","pawar",7845896121,"anacin"],
  //[3,"pallavi","thorat",4567891235,"fecina"]];
//con.query(sql1,[val],function(err,result){
 //if(err){throw err;}
 //console.log('values are inserted');
//})

// Delete

//sql3=' DELETE FROM cust_info WHERE id > 100;';
 //con.query(sql3,function(err,result){
  //if(err){throw err;}
  //console.log(result);
//});


        //update query
//sql2 = 'UPDATE cust_info SET email = 'newemail@example.com', phone = '1234567890' WHERE id = 1;';
//});

});
});
