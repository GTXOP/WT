const no1 = parseFloat(prompt("Enter no 1"));
const no2 = parseFloat(prompt("Enter no 2"));
document.write(no1);
document.write("<br>");
document.write(no2);
document.write("<br>");