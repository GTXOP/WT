function far()
{
 const Result = no1*1.8+32
 // document.write(Result)
 window.alert(Result)
 // console.log(Result)
}

function cel()
{
 const Result = no1-32*5/9
 // document.write(Result)
 window.alert(Result)
 // console.log(Result)
}