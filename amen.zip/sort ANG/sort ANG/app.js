// app.js
angular.module('studentApp', [])
  .controller('StudentController', function ($scope) {
    $scope.students = [
      { name: 'John', city: 'New York' },
      { name: 'Alice', city: 'Los Angeles' },
      { name: 'Bob', city: 'Chicago' },
      // Add more students as needed
    ];

    $scope.orderByField = 'name';
    $scope.reverseSort = false;

    $scope.sort = function (fieldName) {
      if ($scope.orderByField === fieldName) {
        $scope.reverseSort = !$scope.reverseSort;
      } else {
        $scope.reverseSort = false;
      }

      $scope.orderByField = fieldName;
    };
  });
